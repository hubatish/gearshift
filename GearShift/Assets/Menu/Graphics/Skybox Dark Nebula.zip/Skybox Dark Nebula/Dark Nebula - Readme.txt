FEATURES

• 2048x2048px max textures (resizable)
• Seamless textures
• Includes sample scene


Unluck Software
http://www.chemicalbliss.com/

Thanks for purchasing this asset
Have fun with Unity!
